package com.cs5200.sf.action;

public class ExpiringExpired {
	private String itemName;
	private String dateExpired;
	private String daysToExpire;

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDateExpired() {
		return dateExpired;
	}

	public void setDateExpired(String dateExpired) {
		this.dateExpired = dateExpired;
	}

	public String getDaysToExpire() {
		return daysToExpire;
	}

	public void setDaysToExpire(String daysToExpire) {
		this.daysToExpire = daysToExpire;
	}
}
