package com.cs5200.sf.action;

public class Promotions {
	private String promId;
	private String promItem;
	private String promDetail;
	private String iteQquantity;
	private String relatedItem;
	private String discount;
	private String promFlag;

	public String getPromId() {
		return promId;
	}

	public void setPromId(String promId) {
		this.promId = promId;
	}

	public String getPromItem() {
		return promItem;
	}

	public void setPromItem(String promItem) {
		this.promItem = promItem;
	}

	public String getPromDetail() {
		return promDetail;
	}

	public void setPromDetail(String promDetail) {
		this.promDetail = promDetail;
	}

	public String getIteQquantity() {
		return iteQquantity;
	}

	public void setIteQquantity(String iteQquantity) {
		this.iteQquantity = iteQquantity;
	}

	public String getRelatedItem() {
		return relatedItem;
	}

	public void setRelatedItem(String relatedItem) {
		this.relatedItem = relatedItem;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getPromFlag() {
		return promFlag;
	}

	public void setPromFlag(String promFlag) {
		this.promFlag = promFlag;
	}
}
